"""
Enhanced Admin User Creation Script
Creates or updates admin account with security validation
"""
import sys
import re
import uuid


from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from database import SessionLocal, engine
from models.user import User, UserProfile
# ✅ ADD THIS LINE: Import questionnaire so the models are registered before User is mapped
from models.questionnaire import QuestionnaireSession, QuestionnaireSubmission
from utils.auth import get_password_hash
from utils.validation import InputValidator


def validate_username(username):
    """Validate username format"""
    if not username:
        return False, "Username cannot be empty"
    
    if len(username) < 3:
        return False, "Username must be at least 3 characters"
    
    if len(username) > 50:
        return False, "Username must be less than 50 characters"
    
    # Allow alphanumeric, underscore, hyphen, and Chinese characters
    if not re.match(r'^[a-zA-Z0-9_\u4e00-\u9fa5-]+$', username):
        return False, "Username can only contain letters, numbers, underscore, hyphen, and Chinese characters"
    
    return True, ""


def validate_password(password):
    """Validate password strength"""
    if not password:
        return False, "Password cannot be empty"
    
    if len(password) < 8:
        return False, "Password must be at least 8 characters"
    
    # Check for complexity (at least one letter and one number)
    has_letter = any(c.isalpha() for c in password)
    has_number = any(c.isdigit() for c in password)
    
    if not (has_letter and has_number):
        return False, "Password must contain both letters and numbers"
    
    return True, ""


def validate_phone(phone):
    """Validate phone number (Chinese format)"""
    if not phone:
        return True, ""  # Phone is optional
    
    # Chinese mobile phone format
    if not re.match(r'^1[3-9]\d{9}$', phone):
        return False, "Invalid Chinese mobile phone format (should be 11 digits starting with 1)"
    
    return True, ""


def create_admin():
    """Create or update admin user"""
    print("👤 Admin User Management")
    print("=" * 60)
    print()
    
    # Test database connection
    try:
        with engine.connect():
            pass
    except SQLAlchemyError as e:
        print("❌ Cannot connect to database!")
        print(f"   Error: {e}")
        print()
        print("💡 Please:")
        print("   1. Run: python create_db.py")
        print("   2. Run: python init_db.py")
        print("   3. Then run this script again")
        print()
        return False
    
    print("📝 Enter admin account details:")
    print("   (Press Enter to use default values)")
    print()
    
    # Get username with validation
    while True:
        username = input("Username [admin]: ").strip() or "admin"
        valid, error = validate_username(username)
        if valid:
            break
        print(f"❌ {error}")
        print()
    
    # Get password with validation
    while True:
        password = input("Password [admin123!]: ").strip() or "admin123!"
        valid, error = validate_password(password)
        if valid:
            break
        print(f"❌ {error}")
        print()
    
    # Get optional phone number
    phone_number = None
    while True:
        phone_input = input("Phone number (optional, for login): ").strip()
        if not phone_input:
            break
        valid, error = validate_phone(phone_input)
        if valid:
            phone_number = phone_input
            break
        print(f"❌ {error}")
        print()
    
    print()
    
    db = SessionLocal()
    
    try:
        # Check if admin already exists
        existing_admin = db.query(User).filter(User.role == 'admin').first()
        existing_username = db.query(User).filter(User.username == username).first()
        
        if existing_admin or existing_username:
            existing = existing_admin or existing_username
            print("⚠️  Admin user already exists!")
            print()
            print("   Existing admin:")
            print(f"      Username: {existing.username}")
            print(f"      Role: {existing.role}")
            print(f"      Phone: {existing.phone or 'Not set'}")
            print(f"      Active: {'Yes' if existing.is_active else 'No'}")
            print(f"      Verified: {'Yes' if existing.is_verified else 'No'}")
            print()
            
            response = input("Do you want to reset this admin account? (yes/no): ").strip().lower()
            
            if response not in ['yes', 'y']:
                print("❌ Operation cancelled")
                return False
            
            print()
            print("🔄 Resetting admin account...")
            
            # Update existing admin
            existing.username = username
            existing.password_hash = get_password_hash(password)
            existing.phone = phone_number
            existing.role = 'admin'
            existing.is_active = True
            existing.is_verified = True
            
            db.commit()
            db.refresh(existing)
            
            print("✅ Admin account reset successfully!")
            print()
            admin_uuid = str(existing.user_uuid)
        else:
            print("➕ Creating new admin user...")
            
            # Create new admin user
            admin_user = User(
                user_uuid=uuid.uuid4(),
                username=username,
                password_hash=get_password_hash(password),
                phone=phone_number,
                role='admin',
                is_active=True,
                is_verified=True
            )
            
            db.add(admin_user)
            db.commit()
            db.refresh(admin_user)
            
            admin_uuid = str(admin_user.user_uuid)
            
            # Create profile
            print("   Creating user profile...")
            profile = UserProfile(
                user_uuid=admin_user.user_uuid,
                full_name=username,
                description="System Administrator"
            )
            db.add(profile)
            db.commit()
            
            print("✅ Admin user created successfully!")
            print()
        
        # Display credentials
        print("=" * 60)
        print("🔑 Admin Credentials")
        print("=" * 60)
        print(f"   Username: {username}")
        print(f"   Password: {password}")
        if phone_number:
            print(f"   Phone: {phone_number}")
        print(f"   UUID: {admin_uuid}")
        print("=" * 60)
        print()
        
        # Next steps
        print("💡 Next steps:")
        print()
        print("   1. Start Redis:")
        print("      redis-server")
        print()
        print("   2. Start backend:")
        print("      python main.py")
        print("      # Backend will run on http://localhost:8000")
        print()
        print("   3. Start frontend (in another terminal):")
        print("      cd frontend")
        print("      npm run dev")
        print("      # Frontend will run on http://localhost:3000")
        print()
        print("   4. Login to admin dashboard:")
        print("      • Open: http://localhost:3000/login")
        if phone_number:
            print(f"      • Enter phone: {phone_number}")
            print("      • Request verification code")
            print("      • Enter code and login")
        else:
            print("      • Use username/password login")
        print("      • You'll be redirected to admin dashboard")
        print()
        print("🔒 Security Reminders:")
        print("   ⚠️  CHANGE the admin password after first login!")
        print("   • Use a strong, unique password")
        print("   • Enable 2FA if available")
        print("   • Never share admin credentials")
        print("   • Regularly review admin logs")
        print()
        
        return True
        
    except SQLAlchemyError as e:
        print("❌ Database error!")
        print(f"   Error: {str(e)}")
        print()
        db.rollback()
        return False
        
    except Exception as e:
        print("❌ Failed to create admin user!")
        print(f"   Error: {str(e)}")
        print()
        db.rollback()
        return False
        
    finally:
        db.close()


def list_admins():
    """List all admin users"""
    db = SessionLocal()
    try:
        admins = db.query(User).filter(User.role == 'admin').all()
        
        if not admins:
            print("No admin users found")
            return
        
        print(f"\nFound {len(admins)} admin user(s):")
        print()
        for admin in admins:
            print(f"   • {admin.username}")
            print(f"     UUID: {admin.user_uuid}")
            print(f"     Phone: {admin.phone or 'Not set'}")
            print(f"     Active: {'Yes' if admin.is_active else 'No'}")
            print()
    except Exception as e:
        print(f"Error: {e}")
    finally:
        db.close()


def main():
    """Main function"""
    print("\n" + "=" * 60)
    print("  Legal Assistant - Admin User Management")
    print("=" * 60)
    print()
    
    if len(sys.argv) > 1 and sys.argv[1] == "list":
        list_admins()
        return
    
    try:
        success = create_admin()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n❌ Operation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
