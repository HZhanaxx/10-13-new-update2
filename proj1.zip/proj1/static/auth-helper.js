/**
 * Auth Helper - Include this in all protected pages
 * 在所有需要登录的页面引入此文件
 * 
 * Usage in HTML:
 * <script src="/static/auth-helper.js"></script>
 */

const AUTH_CONFIG = {
    API_BASE: '/api/auth',
    LOGIN_PAGE: '/static/login.html',
    REQUIRED_ROLE: null  // Set in individual pages if role check needed
};

// Auto-check authentication on page load
window.addEventListener('DOMContentLoaded', async () => {
    await checkAuthAndRedirect();
});

/**
 * Check if user is authenticated and redirect to login if not
 * 检查用户是否已认证,如果没有则跳转到登录页
 */
async function checkAuthAndRedirect(requiredRole = null) {
    const token = localStorage.getItem('access_token');
    
    // No token, redirect to login
    if (!token) {
        console.log('No token found, redirecting to login...');
        window.location.href = AUTH_CONFIG.LOGIN_PAGE;
        return null;
    }

    try {
        // Verify token with server
        const response = await fetch(`${AUTH_CONFIG.API_BASE}/me`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            // Token is invalid, clear and redirect
            console.log('Invalid token, clearing and redirecting to login...');
            clearAuthData();
            window.location.href = AUTH_CONFIG.LOGIN_PAGE;
            return null;
        }

        const user = await response.json();

        // Check role if required
        if (requiredRole && user.role !== requiredRole) {
            console.log(`Access denied: required role ${requiredRole}, user has ${user.role}`);
            alert('您没有权限访问此页面');
            redirectToHomePage(user.role);
            return null;
        }

        return user;

    } catch (error) {
        console.error('Auth check error:', error);
        clearAuthData();
        window.location.href = AUTH_CONFIG.LOGIN_PAGE;
        return null;
    }
}

/**
 * Get current authenticated user
 * 获取当前认证用户信息
 */
async function getCurrentUser() {
    const token = localStorage.getItem('access_token');
    
    if (!token) {
        return null;
    }

    try {
        const response = await fetch(`${AUTH_CONFIG.API_BASE}/me`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            return await response.json();
        }
        
        return null;
    } catch (error) {
        console.error('Get user error:', error);
        return null;
    }
}

/**
 * Make authenticated API call
 * 发送认证的API请求
 */
async function authenticatedFetch(url, options = {}) {
    const token = localStorage.getItem('access_token');
    
    if (!token) {
        throw new Error('No authentication token');
    }

    const headers = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        ...options.headers
    };

    const response = await fetch(url, {
        ...options,
        headers
    });

    // If unauthorized, clear token and redirect to login
    if (response.status === 401) {
        clearAuthData();
        window.location.href = AUTH_CONFIG.LOGIN_PAGE;
        throw new Error('Authentication failed');
    }

    return response;
}

/**
 * Logout user
 * 登出用户
 */
async function logout() {
    const token = localStorage.getItem('access_token');
    
    if (token) {
        try {
            // Call logout API
            await fetch(`${AUTH_CONFIG.API_BASE}/logout`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            });
        } catch (error) {
            console.error('Logout API error:', error);
        }
    }

    // Clear local data
    clearAuthData();
    
    // Redirect to login
    window.location.href = AUTH_CONFIG.LOGIN_PAGE;
}

/**
 * Clear authentication data
 * 清除认证数据
 */
function clearAuthData() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
}

/**
 * Redirect to appropriate home page based on role
 * 根据角色跳转到对应的主页
 */
function redirectToHomePage(role) {
    switch(role) {
        case 'admin':
            window.location.href = '/static/admin.html';
            break;
        case 'professional':
            window.location.href = '/static/professional.html';
            break;
        case 'user':
        default:
            window.location.href = '/static/dashboard.html';
            break;
    }
}

/**
 * Check if user has specific role
 * 检查用户是否有特定角色
 */
async function hasRole(requiredRole) {
    const user = await getCurrentUser();
    return user && user.role === requiredRole;
}

/**
 * Refresh access token using refresh token
 * 使用refresh token刷新access token
 */
async function refreshAccessToken() {
    const refreshToken = localStorage.getItem('refresh_token');
    
    if (!refreshToken) {
        return false;
    }

    try {
        const response = await fetch(`${AUTH_CONFIG.API_BASE}/token/refresh`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                refresh_token: refreshToken
            })
        });

        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('access_token', data.access_token);
            // Keep the same refresh token
            return true;
        }
        
        return false;
    } catch (error) {
        console.error('Token refresh error:', error);
        return false;
    }
}
