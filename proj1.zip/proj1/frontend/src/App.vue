<template>
  <div id="app">
    <div class="animated-bg">
      <div class="bubble b1"></div>
      <div class="bubble b2"></div>
      <div class="bubble b3"></div>
    </div>
    
    <router-view v-slot="{ Component }">
      <transition name="page-fade" mode="out-in">
        <component :is="Component" />
      </transition>
    </router-view>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useAuthStore } from '@/stores/auth'

const authStore = useAuthStore()

onMounted(async () => {
  await authStore.init()
})
</script>

<style>
/* Global Reset & Fonts */
* { margin: 0; padding: 0; box-sizing: border-box; }
body { 
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; 
  background: #f0f2f5; 
  color: #1a202c; 
  overflow-x: hidden;
}

#app { min-height: 100vh; position: relative; }

/* --- Fancy Background Animation --- */
.animated-bg {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1;
  overflow: hidden;
  background: linear-gradient(135deg, #fdfbfb 0%, #ebedee 100%);
}

.bubble {
  position: absolute;
  border-radius: 50%;
  filter: blur(40px);
  opacity: 0.6;
  animation: float 20s infinite ease-in-out;
}

.b1 { width: 400px; height: 400px; background: #e0c3fc; top: -100px; left: -100px; animation-delay: 0s; }
.b2 { width: 300px; height: 300px; background: #8ec5fc; bottom: -50px; right: -50px; animation-delay: -5s; }
.b3 { width: 350px; height: 350px; background: #96e6a1; top: 40%; left: 60%; animation-delay: -10s; }

@keyframes float {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33% { transform: translate(30px, -50px) scale(1.1); }
  66% { transform: translate(-20px, 20px) scale(0.9); }
}

/* --- Glassmorphism Card Style --- */
.glass-card {
  background: rgba(255, 255, 255, 0.7);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.5);
  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.07);
  border-radius: 16px;
  transition: transform 0.3s ease;
}

/* --- Transitions --- */
.page-fade-enter-active, .page-fade-leave-active { transition: opacity 0.4s ease, transform 0.4s ease; }
.page-fade-enter-from { opacity: 0; transform: translateY(10px); }
.page-fade-leave-to { opacity: 0; transform: translateY(-10px); }

/* --- Common UI Components --- */
.btn { padding: 10px 24px; border-radius: 12px; border: none; cursor: pointer; font-weight: 600; transition: all 0.3s ease; display: inline-flex; align-items: center; justify-content: center; gap: 8px; }
.btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
.btn:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
.btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
.btn-secondary { background: rgba(255,255,255,0.8); color: #475569; border: 1px solid #e2e8f0; }

.input { width: 100%; padding: 14px; border: 1px solid rgba(0,0,0,0.1); border-radius: 10px; background: rgba(255,255,255,0.8); transition: all 0.3s; font-size: 14px; }
.input:focus { outline: none; border-color: #667eea; background: white; box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1); }

.page-container { display: flex; min-height: 100vh; }
.main-content { flex: 1; padding: 40px; position: relative; }
</style>