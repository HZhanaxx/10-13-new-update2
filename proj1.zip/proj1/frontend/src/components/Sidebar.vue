<template>
  <aside class="glass-sidebar">
    <div class="sidebar-header">
      <div class="logo-icon">⚖️</div>
      <span class="logo-text">法律助手</span>
    </div>

    <nav class="sidebar-nav">
      <router-link 
        v-for="item in navigationItems" 
        :key="item.path" 
        :to="item.path" 
        class="nav-item"
        active-class="active"
      >
        <span class="nav-icon">{{ item.icon }}</span>
        <span class="nav-label">{{ item.label }}</span>
      </router-link>
    </nav>

    <div class="sidebar-footer">
      <div class="user-card">
        <div class="user-avatar">{{ userInitial }}</div>
        <div class="user-info">
          <div class="user-name">{{ authStore.userName }}</div>
          <div class="user-role">{{ getRoleName(authStore.userRole) }}</div>
        </div>
        <button class="btn-logout" @click="handleLogout">➔</button>
      </div>
    </div>
  </aside>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const authStore = useAuthStore()

const navigationItems = computed(() => {
  const role = authStore.userRole
  
  // Shared Items
  const profile = { path: '/profile', icon: '👤', label: '个人资料' }

  if (role === 'admin') {
    return [
      { path: '/admin', icon: '📊', label: '概览面板' },
      { path: '/admin/users', icon: '👥', label: '用户管理' },
      { path: '/admin/cases', icon: '🧿', label: '案件监控' },
      profile
    ]
  } else if (role === 'professional') {
    return [
      { path: '/professional', icon: '💼', label: '工作台' },
      { path: '/case-pool', icon: '📁', label: '案件池' },
      { path: '/professional/my-cases', icon: '📋', label: '我的案件' },
      profile
    ]
  } else {
    return [
      { path: '/dashboard', icon: '🏠', label: '我的案件' },
      { path: '/cases/new', icon: '➕', label: '新建案件' },
      profile
    ]
  }
})

const userInitial = computed(() => (authStore.userName ? authStore.userName.charAt(0).toUpperCase() : 'U'))

const getRoleName = (role) => {
  const map = { admin: '管理员', professional: '专业人员', user: '普通用户' }
  return map[role] || role
}

const handleLogout = async () => {
  await authStore.logout()
  router.push('/login')
}
</script>

<style scoped>
.glass-sidebar {
  width: 260px;
  height: 100vh;
  background: rgba(255, 255, 255, 0.65);
  backdrop-filter: blur(12px);
  border-right: 1px solid rgba(255, 255, 255, 0.5);
  display: flex;
  flex-direction: column;
  position: sticky;
  top: 0;
}

.sidebar-header {
  padding: 30px;
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 20px;
  font-weight: 700;
  color: #2d3748;
}

.logo-icon { font-size: 24px; }

.sidebar-nav { flex: 1; padding: 0 16px; }

.nav-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 16px;
  border-radius: 12px;
  color: #718096;
  text-decoration: none;
  margin-bottom: 8px;
  transition: all 0.3s ease;
  font-weight: 500;
}

.nav-item:hover { background: rgba(255, 255, 255, 0.5); color: #4a5568; }
.nav-item.active { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3); }

.sidebar-footer { padding: 20px; border-top: 1px solid rgba(0,0,0,0.05); }

.user-card {
  display: flex;
  align-items: center;
  gap: 12px;
  background: rgba(255, 255, 255, 0.5);
  padding: 12px;
  border-radius: 12px;
}

.user-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: #cbd5e0;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
}

.user-info { flex: 1; overflow: hidden; }
.user-name { font-size: 14px; font-weight: 600; color: #2d3748; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.user-role { font-size: 11px; color: #718096; }

.btn-logout { border: none; background: none; cursor: pointer; color: #a0aec0; font-size: 16px; padding: 4px; transition: color 0.2s; }
.btn-logout:hover { color: #e53e3e; }
</style>