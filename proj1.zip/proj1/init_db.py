"""
Enhanced Database Initialization Script
Creates all tables with security checks and validation
"""
import sys
import os
from sqlalchemy import text, inspect
from sqlalchemy.exc import SQLAlchemyError
from database import engine, Base, SessionLocal
from models.user import (
    User, UserSession, RefreshToken, SMSVerification, 
    UserProfile, Professional, ProfessionalVerification, AdminLog, Case,
    DocumentTemplate, Document, DocumentData
)
from models.questionnaire import QuestionnaireSession, QuestionnaireSubmission
from config import settings


def check_database_connection():
    """Test database connection and get version info"""
    try:
        with engine.connect() as conn:
            result = conn.execute(text("SELECT version();"))
            version = result.fetchone()[0]
            return True, version
    except SQLAlchemyError as e:
        return False, str(e)


def get_existing_tables():
    """Get list of existing tables"""
    try:
        inspector = inspect(engine)
        return inspector.get_table_names()
    except Exception as e:
        print(f"⚠️  Warning: Could not inspect database: {e}")
        return []


def init_database():
    """Initialize the database with all tables"""
    print("🚀 Database Initialization")
    print("=" * 60)
    print()
    
    # Check if DATABASE_URL is set
    if not settings.DATABASE_URL or settings.DATABASE_URL == "sqlite:///./test.db":
        print("❌ DATABASE_URL not configured!")
        print()
        print("💡 Please:")
        print("   1. Run: python create_db.py")
        print("   2. Or manually set DATABASE_URL in .env")
        print()
        return False
    
    # Sanitize URL for display (hide password)
    display_url = settings.DATABASE_URL
    if '@' in display_url:
        # Hide password
        parts = display_url.split('@')
        if '://' in parts[0]:
            proto_user = parts[0].split('://')
            if ':' in proto_user[1]:
                user = proto_user[1].split(':')[0]
                display_url = f"{proto_user[0]}://{user}:****@{parts[1]}"
    
    print(f"📡 Database: {display_url}")
    print()
    
    # Test connection
    print("🔌 Testing database connection...")
    connected, info = check_database_connection()
    
    if not connected:
        print(f"❌ Connection failed!")
        print(f"   Error: {info}")
        print()
        print("💡 Troubleshooting:")
        print("   1. Verify DATABASE_URL in .env is correct")
        print("   2. Ensure PostgreSQL is running:")
        print("      • sudo systemctl status postgresql")
        print("   3. Check database exists:")
        print("      • Run: python create_db.py")
        print("   4. Test connection manually:")
        print("      • Extract host, port, user, db from DATABASE_URL")
        print("      • Run: psql -h <host> -p <port> -U <user> -d <database>")
        print()
        return False
    
    print(f"✅ Connected successfully!")
    print(f"   PostgreSQL version: {info[:60]}...")
    print()
    
    # Check existing tables
    print("🔍 Checking existing tables...")
    existing_tables = get_existing_tables()
    
    if existing_tables:
        print(f"   Found {len(existing_tables)} existing table(s):")
        for table in existing_tables[:5]:  # Show first 5
            print(f"      • {table}")
        if len(existing_tables) > 5:
            print(f"      ... and {len(existing_tables) - 5} more")
        print()
        
        # Ask for confirmation
        response = input("⚠️  Some tables already exist. Continue and create missing tables? (yes/no): ").strip().lower()
        if response not in ['yes', 'y']:
            print("❌ Operation cancelled")
            return False
        print()
    
    # Create all tables
    try:
        print("📊 Creating database tables...")
        Base.metadata.create_all(bind=engine)
        print("✅ Tables created successfully!")
        print()
        
        # Verify tables were created
        print("🔍 Verifying created tables...")
        final_tables = get_existing_tables()
        
        # Updated: All tables from schema_combined.sql
        expected_tables = [
            'users', 'user_profiles', 'user_sessions', 'refresh_tokens',
            'sms_verification', 'professionals', 'professional_verifications', 'admin_logs',
            'cases', 'document_templates', 'documents', 'document_data',
            'questionnaire_sessions', 'questionnaire_submissions'
        ]
        
        print()
        print("📋 Database Tables:")
        print("=" * 60)
        
        created_count = 0
        for table_name in expected_tables:
            if table_name in final_tables:
                print(f"   ✅ {table_name}")
                created_count += 1
            else:
                print(f"   ⚠️  {table_name} (not found)")
        
        print("=" * 60)
        print(f"   Total: {created_count}/{len(expected_tables)} tables")
        print()
        
        if created_count == 0:
            print("❌ No tables were created!")
            print()
            print("💡 This might mean:")
            print("   • Database user lacks CREATE TABLE privilege")
            print("   • Connection issue during table creation")
            print("   • Model definitions have errors")
            return False
        
        # Success message
        print("=" * 60)
        print("✅ Database initialization complete!")
        print("=" * 60)
        print()
        print("💡 Next steps:")
        print()
        print("   1. Create admin user:")
        print("      python create_admin.py")
        print()
        print("   2. Start Redis (for sessions and caching):")
        print("      redis-server")
        print("      # Or with Docker:")
        print("      docker run -d -p 6379:6379 redis:7-alpine")
        print()
        print("   3. Start backend:")
        print("      python main.py")
        print()
        print("   4. Start frontend (in another terminal):")
        print("      cd frontend")
        print("      npm run dev")
        print()
        print("   5. Access application:")
        print("      http://localhost:3000")
        print()
        print("🔒 Security Reminders:")
        print("   • Change default SECRET_KEY in .env")
        print("   • Use strong admin password")
        print("   • Enable SSL/TLS in production")
        print("   • Regularly backup database")
        print()
        
        return True
        
    except SQLAlchemyError as e:
        print(f"❌ Database error!")
        print(f"   Error: {str(e)}")
        print()
        print("💡 Troubleshooting:")
        print("   1. Check database user has CREATE TABLE privilege")
        print("   2. Verify all model imports are correct")
        print("   3. Check for syntax errors in models")
        print("   4. Review database logs for details")
        print()
        return False
        
    except Exception as e:
        print(f"❌ Unexpected error!")
        print(f"   Error: {str(e)}")
        print()
        return False


def create_indexes():
    """Create performance indexes (optional, for production)"""
    print("\n📊 Creating performance indexes...")
    
    db = SessionLocal()
    try:
        # Updated indexes for new schema
        indexes = [
            # User tables
            "CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);",
            "CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);",
            "CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);",
            
            # Case tables
            "CREATE INDEX IF NOT EXISTS idx_cases_user ON cases(user_uuid);",
            "CREATE INDEX IF NOT EXISTS idx_cases_professional ON cases(professional_uuid);",
            "CREATE INDEX IF NOT EXISTS idx_cases_status ON cases(case_status);",
            "CREATE INDEX IF NOT EXISTS idx_cases_created ON cases(created_at DESC);",
            
            # Session tables
            "CREATE INDEX IF NOT EXISTS idx_sessions_user ON user_sessions(user_uuid);",
            "CREATE INDEX IF NOT EXISTS idx_sessions_token ON user_sessions(access_token_jti);",
            
            # Professional verification tables
            "CREATE INDEX IF NOT EXISTS idx_prof_verif_user ON professional_verifications(user_uuid);",
            "CREATE INDEX IF NOT EXISTS idx_prof_verif_status ON professional_verifications(status);",
            
            # Document tables (unified)
            "CREATE INDEX IF NOT EXISTS idx_documents_user ON documents(user_uuid);",
            "CREATE INDEX IF NOT EXISTS idx_documents_case ON documents(case_uuid);",
            "CREATE INDEX IF NOT EXISTS idx_documents_session ON documents(session_id);",
            "CREATE INDEX IF NOT EXISTS idx_documents_type ON documents(document_type);",
            "CREATE INDEX IF NOT EXISTS idx_document_data_doc ON document_data(document_id);",
            "CREATE INDEX IF NOT EXISTS idx_document_data_type ON document_data(data_type);",
            
            # Questionnaire tables
            "CREATE INDEX IF NOT EXISTS idx_q_sessions_user ON questionnaire_sessions(user_uuid);",
            "CREATE INDEX IF NOT EXISTS idx_q_sessions_status ON questionnaire_sessions(status);",
            "CREATE INDEX IF NOT EXISTS idx_q_sessions_case ON questionnaire_sessions(case_uuid);",
            "CREATE INDEX IF NOT EXISTS idx_q_sessions_expires ON questionnaire_sessions(expires_at);",
            "CREATE INDEX IF NOT EXISTS idx_q_submissions_user ON questionnaire_submissions(user_uuid);",
            "CREATE INDEX IF NOT EXISTS idx_q_submissions_case ON questionnaire_submissions(case_uuid);",
            "CREATE INDEX IF NOT EXISTS idx_q_submissions_status ON questionnaire_submissions(processing_status);",
        ]
        
        for index_sql in indexes:
            try:
                db.execute(text(index_sql))
                db.commit()
            except Exception as e:
                print(f"   ⚠️  Warning: {e}")
        
        print("   ✅ Indexes created")
        
    except Exception as e:
        print(f"   ⚠️  Could not create indexes: {e}")
    finally:
        db.close()


def main():
    """Main function"""
    print("\n" + "=" * 60)
    print("  Legal Assistant - Database Initialization")
    print("=" * 60)
    print()
    
    try:
        # Initialize database
        success = init_database()
        
        if success:
            # Optionally create indexes
            try:
                response = input("\n📊 Create performance indexes? (recommended for production) (yes/no): ").strip().lower()
                if response in ['yes', 'y']:
                    create_indexes()
            except KeyboardInterrupt:
                print("\n   Skipped indexes")
        
        sys.exit(0 if success else 1)
        
    except KeyboardInterrupt:
        print("\n\n❌ Operation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
