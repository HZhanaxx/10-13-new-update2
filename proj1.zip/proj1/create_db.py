"""
Enhanced Database Creation Script
Creates PostgreSQL database with security checks
"""
import sys
import re
import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from psycopg2 import sql


def validate_input(value, pattern, field_name):
    """Validate input against pattern"""
    if not re.match(pattern, value):
        raise ValueError(f"Invalid {field_name} format")
    return value


def create_database():
    """Create the database if it doesn't exist"""
    
    print("🔧 PostgreSQL Database Creation")
    print("=" * 60)
    print()
    
    # Get database connection details with validation
    print("📝 Enter PostgreSQL connection details:")
    print("   (Press Enter to use default values)")
    print()
    
    try:
        # Host validation
        host = input("Host [localhost]: ").strip() or "localhost"
        # Allow localhost, IPs, and domain names
        if not re.match(r'^(localhost|[\w\.-]+|\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$', host):
            raise ValueError("Invalid host format")
        
        # Port validation
        port_input = input("Port [5432]: ").strip() or "5432"
        port = int(port_input)
        if not 1 <= port <= 65535:
            raise ValueError("Port must be between 1 and 65535")
        
        # User validation (alphanumeric, underscore, hyphen)
        user = input("Admin user [postgres]: ").strip() or "postgres"
        if not re.match(r'^[a-zA-Z0-9_-]+$', user):
            raise ValueError("Username can only contain letters, numbers, underscore, and hyphen")
        
        # Password (no validation on content, just check it's not empty)
        password = input("Admin password: ").strip()
        if not password:
            raise ValueError("Password cannot be empty")
        
        # Database name validation (alphanumeric and underscore only)
        db_name = input("Database name to create [legal_assistant]: ").strip() or "legal_assistant"
        if not re.match(r'^[a-zA-Z0-9_]+$', db_name):
            raise ValueError("Database name can only contain letters, numbers, and underscore")
        
        print()
        
        # New app user details
        print("📝 Enter application database user details:")
        print("   (This user will be used by the application)")
        print()
        
        app_user = input(f"App user [{db_name}_user]: ").strip() or f"{db_name}_user"
        if not re.match(r'^[a-zA-Z0-9_-]+$', app_user):
            raise ValueError("App username can only contain letters, numbers, underscore, and hyphen")
        
        app_password = input("App user password: ").strip()
        if not app_password:
            raise ValueError("App password cannot be empty")
        
        if len(app_password) < 8:
            print("⚠️  Warning: Password is less than 8 characters")
        
    except ValueError as e:
        print(f"\n❌ Input validation error: {e}")
        return False
    except KeyboardInterrupt:
        print("\n\n❌ Operation cancelled by user")
        return False
    
    try:
        # Connect to PostgreSQL server
        print(f"\n🔌 Connecting to PostgreSQL at {host}:{port}...")
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            database='postgres'
        )
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        
        # Check PostgreSQL version
        cursor.execute("SELECT version();")
        version = cursor.fetchone()[0]
        print(f"✅ Connected to PostgreSQL")
        print(f"   Version: {version[:60]}...")
        
        # Check if database exists
        print(f"\n🔍 Checking if database '{db_name}' exists...")
        cursor.execute(
            "SELECT 1 FROM pg_database WHERE datname = %s",
            (db_name,)
        )
        db_exists = cursor.fetchone()
        
        if db_exists:
            print(f"✅ Database '{db_name}' already exists!")
        else:
            # Create database using sql.Identifier for safety
            print(f"📊 Creating database '{db_name}'...")
            cursor.execute(
                sql.SQL("CREATE DATABASE {} ENCODING 'UTF8'").format(
                    sql.Identifier(db_name)
                )
            )
            print(f"✅ Database '{db_name}' created successfully!")
        
        # Check if app user exists
        print(f"\n🔍 Checking if user '{app_user}' exists...")
        cursor.execute(
            "SELECT 1 FROM pg_user WHERE usename = %s",
            (app_user,)
        )
        user_exists = cursor.fetchone()
        
        if user_exists:
            print(f"✅ User '{app_user}' already exists!")
            
            # Update password
            print(f"🔐 Updating password for '{app_user}'...")
            cursor.execute(
                sql.SQL("ALTER USER {} WITH PASSWORD %s").format(
                    sql.Identifier(app_user)
                ),
                (app_password,)
            )
            print(f"✅ Password updated!")
        else:
            # Create app user
            print(f"👤 Creating user '{app_user}'...")
            cursor.execute(
                sql.SQL("CREATE USER {} WITH PASSWORD %s").format(
                    sql.Identifier(app_user)
                ),
                (app_password,)
            )
            print(f"✅ User '{app_user}' created!")
        
        # Grant privileges
        print(f"\n🔑 Granting privileges to '{app_user}' on '{db_name}'...")
        cursor.execute(
            sql.SQL("GRANT ALL PRIVILEGES ON DATABASE {} TO {}").format(
                sql.Identifier(db_name),
                sql.Identifier(app_user)
            )
        )
        print(f"✅ Privileges granted!")
        
        cursor.close()
        conn.close()
        
        # Create connection strings
        print("\n" + "=" * 60)
        print("✅ Database setup complete!")
        print("=" * 60)
        print()
        print("📋 Add this to your .env file:")
        print()
        print("# Database Configuration")
        print(f"DATABASE_URL=postgresql://{app_user}:{app_password}@{host}:{port}/{db_name}")
        print()
        print("# For SSL/TLS in production, append: ?sslmode=require")
        print(f"# DATABASE_URL=postgresql://{app_user}:{app_password}@{host}:{port}/{db_name}?sslmode=require")
        print()
        print("=" * 60)
        print()
        print("💡 Next steps:")
        print("   1. Update your .env file with DATABASE_URL above")
        print("   2. Run: python init_db.py (to create tables)")
        print("   3. Run: python create_admin.py (to create admin user)")
        print("   4. Start backend: python main.py")
        print("   5. Start frontend: cd frontend && npm run dev")
        print()
        print("🔒 Security Reminder:")
        print("   • Keep database credentials secure")
        print("   • Use strong passwords (8+ characters)")
        print("   • Enable SSL/TLS in production")
        print("   • Regularly backup your database")
        print()
        
        return True
        
    except psycopg2.OperationalError as e:
        print(f"\n❌ Connection failed!")
        print(f"   Error: {e}")
        print()
        print("💡 Troubleshooting:")
        print("   1. Ensure PostgreSQL is running:")
        print("      • sudo systemctl status postgresql")
        print("      • sudo systemctl start postgresql")
        print("   2. Check your username and password")
        print("   3. Verify PostgreSQL accepts connections:")
        print("      • Check postgresql.conf: listen_addresses")
        print("      • Check pg_hba.conf: host authentication")
        print("   4. Test connection manually:")
        print(f"      • psql -h {host} -p {port} -U {user} -d postgres")
        print()
        return False
        
    except psycopg2.Error as e:
        print(f"\n❌ Database error!")
        print(f"   Error: {e}")
        print()
        return False
        
    except Exception as e:
        print(f"\n❌ Unexpected error!")
        print(f"   Error: {e}")
        print()
        return False


def main():
    """Main function"""
    print("\n" + "=" * 60)
    print("  PostgreSQL Database Setup for Legal Assistant")
    print("=" * 60)
    print()
    print("This script will:")
    print("  1. Create the database")
    print("  2. Create application user")
    print("  3. Grant necessary privileges")
    print()
    
    try:
        success = create_database()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n❌ Operation cancelled by user")
        sys.exit(1)


if __name__ == "__main__":
    main()
