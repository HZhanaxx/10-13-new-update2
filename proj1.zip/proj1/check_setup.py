"""
All-in-One Setup Checker and Initialization Script
This script checks all dependencies and helps you set up the authentication system
"""
import sys
import subprocess
import os
from pathlib import Path


def print_header(text):
    """Print a formatted header"""
    print("\n" + "=" * 60)
    print(f"  {text}")
    print("=" * 60)


def print_status(status, message):
    """Print status message"""
    symbols = {"success": "✅", "error": "❌", "warning": "⚠️", "info": "ℹ️"}
    print(f"{symbols.get(status, '•')} {message}")


def check_python_version():
    """Check Python version"""
    print_header("Checking Python Version")
    version = sys.version_info
    if version >= (3, 8):
        print_status("success", f"Python {version.major}.{version.minor}.{version.micro} - OK")
        return True
    else:
        print_status("error", f"Python {version.major}.{version.minor} - Requires Python 3.8+")
        return False


def check_dependencies():
    """Check if required packages are installed"""
    print_header("Checking Python Dependencies")
    
    required = [
        'fastapi', 'uvicorn', 'sqlalchemy', 'psycopg2',
        'redis', 'pydantic', 'python-jose', 'passlib'
    ]
    
    missing = []
    for package in required:
        try:
            __import__(package.replace('-', '_'))
            print_status("success", f"{package} installed")
        except ImportError:
            print_status("error", f"{package} NOT installed")
            missing.append(package)
    
    if missing:
        print_status("warning", "Missing packages. Run: pip install -r requirements.txt")
        return False
    return True


def check_postgresql():
    """Check PostgreSQL connection"""
    print_header("Checking PostgreSQL")
    
    try:
        import psycopg2
        from config import settings
        
        # Parse DATABASE_URL
        db_url = settings.DATABASE_URL
        print_status("info", f"Attempting connection to: {db_url.split('@')[1] if '@' in db_url else 'database'}")
        
        # Try to connect
        from sqlalchemy import create_engine, text
        engine = create_engine(db_url)
        with engine.connect() as conn:
            result = conn.execute(text("SELECT version();"))
            version = result.fetchone()[0]
            print_status("success", "PostgreSQL connected successfully")
            print_status("info", f"Version: {version[:50]}...")
        return True
        
    except ImportError:
        print_status("error", "psycopg2 not installed")
        return False
    except Exception as e:
        print_status("error", f"Cannot connect to PostgreSQL: {str(e)}")
        print_status("warning", "Run: python create_db.py to create database")
        return False


def check_redis():
    """Check Redis connection"""
    print_header("Checking Redis")
    
    try:
        import redis
        from config import settings
        
        r = redis.Redis(
            host=settings.REDIS_HOST,
            port=settings.REDIS_PORT,
            db=settings.REDIS_DB,
            password=settings.REDIS_PASSWORD,
            decode_responses=True
        )
        
        # Test connection
        r.ping()
        print_status("success", f"Redis connected at {settings.REDIS_HOST}:{settings.REDIS_PORT}")
        
        # Get info
        info = r.info()
        print_status("info", f"Redis version: {info.get('redis_version', 'unknown')}")
        return True
        
    except ImportError:
        print_status("error", "redis package not installed")
        return False
    except Exception as e:
        print_status("error", f"Cannot connect to Redis: {str(e)}")
        print_status("warning", "Start Redis with: redis-server")
        print_status("warning", "Or use Docker: docker run -d -p 6379:6379 redis:7")
        return False


def check_env_file():
    """Check if .env file exists"""
    print_header("Checking Configuration")
    
    env_path = Path(".env")
    if env_path.exists():
        print_status("success", ".env file found")
        return True
    else:
        print_status("warning", ".env file not found")
        print_status("info", "Creating .env from .env.example...")
        
        example_path = Path(".env.example")
        if example_path.exists():
            import shutil
            shutil.copy(example_path, env_path)
            print_status("success", ".env created from .env.example")
            print_status("warning", "Please update .env with your configuration")
            return False
        else:
            print_status("error", ".env.example not found")
            return False


def check_database_tables():
    """Check if database tables exist"""
    print_header("Checking Database Tables")
    
    try:
        from sqlalchemy import create_engine, inspect
        from config import settings
        
        engine = create_engine(settings.DATABASE_URL)
        inspector = inspect(engine)
        tables = inspector.get_table_names()
        
        required_tables = ['users', 'user_profiles', 'user_sessions', 'refresh_tokens', 'sms_verification']
        
        if not tables:
            print_status("warning", "No tables found in database")
            print_status("info", "Run: python init_db.py to create tables")
            return False
        
        missing = [t for t in required_tables if t not in tables]
        
        if missing:
            print_status("warning", f"Missing tables: {', '.join(missing)}")
            print_status("info", "Run: python init_db.py to create tables")
            return False
        else:
            print_status("success", "All required tables exist")
            for table in tables:
                print_status("info", f"  - {table}")
            return True
            
    except Exception as e:
        print_status("error", f"Cannot check tables: {str(e)}")
        return False


def main():
    """Main setup checker"""
    print("\n" + "🚀" * 30)
    print("\n  Authentication System Setup Checker")
    print("\n" + "🚀" * 30)
    
    checks = []
    
    # Run all checks
    checks.append(("Python Version", check_python_version()))
    checks.append(("Python Dependencies", check_dependencies()))
    checks.append(("Configuration File", check_env_file()))
    checks.append(("PostgreSQL", check_postgresql()))
    checks.append(("Redis", check_redis()))
    checks.append(("Database Tables", check_database_tables()))
    
    # Summary
    print_header("Setup Summary")
    
    passed = sum(1 for _, status in checks if status)
    total = len(checks)
    
    for name, status in checks:
        symbol = "✅" if status else "❌"
        print(f"{symbol} {name}")
    
    print(f"\n📊 Status: {passed}/{total} checks passed")
    
    if passed == total:
        print_status("success", "All checks passed! 🎉")
        print("\n💡 Next steps:")
        print("   1. Run: python main.py")
        print("   2. Open: http://localhost:8000/login.html")
        print("   3. Register a test user")
    else:
        print_status("warning", "Some checks failed. Please fix the issues above.")
        print("\n💡 Quick fixes:")
        print("   1. Install dependencies: pip install -r requirements.txt")
        print("   2. Create database: python create_db.py")
        print("   3. Start Redis: redis-server (or docker run -d -p 6379:6379 redis:7)")
        print("   4. Initialize tables: python init_db.py")
    
    print("\n" + "=" * 60)
    
    return passed == total


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
