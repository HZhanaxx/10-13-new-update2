# Application Constants

# Case Categories - used for both case creation and professional specialization
CASE_CATEGORIES = [
    "民事诉讼",      # Civil Litigation
    "刑事辩护",      # Criminal Defense
    "商事纠纷",      # Commercial Disputes
    "劳动争议",      # Labor Disputes
    "婚姻家庭",      # Marriage & Family
    "房产纠纷",      # Real Estate Disputes
    "知识产权",      # Intellectual Property
    "行政诉讼",      # Administrative Litigation
    "公司法务",      # Corporate Legal Affairs
    "合同纠纷",      # Contract Disputes
    "侵权责任",      # Tort Liability
    "债权债务",      # Debt & Credit
    "交通事故",      # Traffic Accidents
    "医疗纠纷",      # Medical Malpractice
    "其他",          # Other
]

# Case Priority Levels
CASE_PRIORITIES = [
    ("low", "低优先"),
    ("medium", "中等"),
    ("high", "高优先"),
    ("urgent", "紧急"),
]

# Case Status
CASE_STATUS = [
    ("pending", "待接受"),
    ("accepted", "已接受"),
    ("in_progress", "进行中"),
    ("completed", "已完成"),
    ("cancelled", "已取消"),
]

# Field Length Limits (from database schema)
FIELD_LIMITS = {
    # User fields
    "username": 50,
    "phone": 20,
    "full_name": 100,
    "nickname": 50,
    "city_name": 50,
    "province_name": 50,
    "postal_code": 10,
    "id_card_number": 18,
    
    # Professional fields
    "license_number": 50,
    "law_firm_name": 200,
    
    # Case fields
    "case_title": 200,
    "case_category": 50,
    "document_name": 255,
    
    # Other limits
    "description": 5000,  # Reasonable limit for Text fields
    "bio": 2000,
    "education_background": 1000,
    "address_line": 200,
}

# Professional Account Status
PROFESSIONAL_STATUS = [
    ("active", "活跃"),
    ("inactive", "不活跃"),
    ("suspended", "已暂停"),
]
