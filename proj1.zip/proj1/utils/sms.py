import random
import string
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from fastapi import HTTPException, status
import uuid

from models.user import SMSVerification
from config import settings


def generate_verification_code(length: int = 6) -> str:
    """Generate random numeric verification code"""
    return ''.join(random.choices(string.digits, k=length))


async def send_sms_code(phone: str, code: str, purpose: str) -> bool:
    """
    Send SMS verification code
    
    This is a placeholder - implement your SMS provider here
    Options: Aliyun SMS, Tencent Cloud SMS, Twilio, etc.
    
    Args:
        phone: Phone number
        code: Verification code
        purpose: Purpose of SMS (login, register, reset_password)
        
    Returns:
        bool: Success status
    """
    # TODO: Implement actual SMS sending logic
    # Example with Aliyun SMS:
    # from aliyunsdkcore.client import AcsClient
    # from aliyunsdkcore.request import CommonRequest
    
    # Example with Twilio:
    # from twilio.rest import Client
    # client = Client(account_sid, auth_token)
    # message = client.messages.create(
    #     body=f"Your verification code is: {code}",
    #     from_='+1234567890',
    #     to=phone
    # )
    
    # For development/testing, just print the code
    print(f"[SMS] Sending code {code} to {phone} for {purpose}")
    
    # Simulate successful send
    return True


def create_sms_verification(
    db: Session,
    phone: str,
    purpose: str,
    ip_address: str = None
) -> SMSVerification:
    """
    Create SMS verification record
    
    Args:
        db: Database session
        phone: Phone number
        purpose: Purpose (login, register, reset_password)
        ip_address: Client IP address
        
    Returns:
        SMSVerification record
    """
    # Check rate limiting: max 1 SMS per minute per phone
    recent_sms = db.query(SMSVerification).filter(
        SMSVerification.phone == phone,
        SMSVerification.created_at > datetime.utcnow() - timedelta(minutes=1)
    ).first()
    
    if recent_sms:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="请等待60秒后再次发送验证码"
        )
    
    # Check daily limit: max 10 SMS per day per phone
    today_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    daily_count = db.query(SMSVerification).filter(
        SMSVerification.phone == phone,
        SMSVerification.created_at >= today_start
    ).count()
    
    if daily_count >= 10:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="今日验证码发送次数已达上限"
        )
    
    # Generate verification code
    code = generate_verification_code()
    
    # Create verification record
    verification = SMSVerification(
        phone=phone,
        verification_code=code,
        purpose=purpose,
        ip_address=ip_address,
        expires_at=datetime.utcnow() + timedelta(minutes=settings.SMS_CODE_EXPIRE_MINUTES)
    )
    
    db.add(verification)
    db.commit()
    db.refresh(verification)
    
    return verification


def verify_sms_code(
    db: Session,
    phone: str,
    code: str,
    purpose: str
) -> bool:
    """
    Verify SMS code
    
    Args:
        db: Database session
        phone: Phone number
        code: Verification code to verify
        purpose: Purpose must match
        
    Returns:
        bool: Verification success
        
    Raises:
        HTTPException: If verification fails
    """
    # Find the most recent unused verification
    verification = db.query(SMSVerification).filter(
        SMSVerification.phone == phone,
        SMSVerification.purpose == purpose,
        SMSVerification.is_used == False,
        SMSVerification.expires_at > datetime.utcnow()
    ).order_by(SMSVerification.created_at.desc()).first()
    
    if not verification:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="验证码不存在或已过期"
        )
    
    # Check max attempts
    if verification.attempt_count >= verification.max_attempts:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="验证码尝试次数过多,请重新发送"
        )
    
    # Increment attempt count
    verification.attempt_count += 1
    
    # Verify code
    if verification.verification_code != code:
        db.commit()
        remaining = verification.max_attempts - verification.attempt_count
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"验证码错误,还有{remaining}次尝试机会"
        )
    
    # Mark as used
    verification.is_used = True
    verification.used_at = datetime.utcnow()
    db.commit()
    
    return True


def cleanup_expired_codes(db: Session):
    """Clean up expired SMS verification codes"""
    db.query(SMSVerification).filter(
        SMSVerification.expires_at < datetime.utcnow()
    ).delete()
    db.commit()
