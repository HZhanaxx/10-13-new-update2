"""
Middleware to check professional verification status
Blocks access to case pool and professional features for unverified professionals
"""
from fastapi import HTTPException, status, Depends
from sqlalchemy.orm import Session
from database import get_db
from models.user import User, Professional
from utils.auth import get_current_user


async def require_verified_professional(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Dependency that requires user to be a verified professional
    Use this to protect routes that should only be accessible to verified professionals
    """
    # Check if user is professional
    if current_user.role != 'professional':
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="只有专业人士可以访问此功能"
        )
    
    # Check if professional record exists and is verified
    professional = db.query(Professional).filter(
        Professional.user_uuid == current_user.user_uuid
    ).first()
    
    if not professional:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="请先完成专业认证",
            headers={"X-Verification-Required": "true"}
        )
    
    if not professional.is_verified:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="您的认证尚未通过审核,暂时无法访问此功能",
            headers={"X-Verification-Pending": "true"}
        )
    
    # Check account status
    if professional.account_status != 'active':
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"账号状态异常: {professional.account_status}"
        )
    
    return professional


async def get_professional_status(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
) -> dict:
    """
    Get professional verification status
    Returns status dict without blocking access
    """
    if current_user.role != 'professional':
        return {
            "is_professional": False,
            "is_verified": False,
            "status": "not_professional"
        }
    
    professional = db.query(Professional).filter(
        Professional.user_uuid == current_user.user_uuid
    ).first()
    
    if not professional:
        return {
            "is_professional": True,
            "is_verified": False,
            "status": "not_verified",
            "message": "请先完成专业认证"
        }
    
    return {
        "is_professional": True,
        "is_verified": professional.is_verified,
        "status": "verified" if professional.is_verified else "pending",
        "account_status": professional.account_status,
        "professional_uuid": str(professional.professional_uuid),
        "license_number": professional.license_number,
        "law_firm_name": professional.law_firm_name,
        "verified_at": professional.verified_at.isoformat() if professional.verified_at else None
    }
