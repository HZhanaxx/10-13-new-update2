import httpx
from typing import Optional, Dict
from fastapi import HTTPException, status
from config import settings


class WeChatOAuth:
    """WeChat OAuth 2.0 handler"""
    
    # WeChat OAuth URLs
    AUTHORIZE_URL = "https://open.weixin.qq.com/connect/oauth2/authorize"
    ACCESS_TOKEN_URL = "https://api.weixin.qq.com/sns/oauth2/access_token"
    USER_INFO_URL = "https://api.weixin.qq.com/sns/userinfo"
    
    def __init__(self):
        self.app_id = settings.WECHAT_APP_ID
        self.app_secret = settings.WECHAT_APP_SECRET
        self.redirect_uri = settings.WECHAT_REDIRECT_URI
        self.enabled = settings.is_wechat_enabled()
    
    def check_enabled(self):
        """Check if WeChat OAuth is enabled and properly configured"""
        if not self.enabled:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="WeChat login is not configured. Please set WECHAT_APP_ID and WECHAT_APP_SECRET in .env"
            )
    
    def get_authorization_url(self, state: Optional[str] = None) -> str:
        """
        Generate WeChat authorization URL
        
        Args:
            state: Optional state parameter for CSRF protection
            
        Returns:
            Authorization URL string
        """
        self.check_enabled()
        
        params = {
            "appid": self.app_id,
            "redirect_uri": self.redirect_uri,
            "response_type": "code",
            "scope": "snsapi_userinfo",  # Use snsapi_base for basic info only
            "state": state or "STATE"
        }
        
        query_string = "&".join([f"{k}={v}" for k, v in params.items()])
        return f"{self.AUTHORIZE_URL}?{query_string}#wechat_redirect"
    
    async def get_access_token(self, code: str) -> Dict:
        """
        Exchange authorization code for access token
        
        Args:
            code: Authorization code from WeChat
            
        Returns:
            Dict containing access_token, openid, unionid, etc.
        """
        params = {
            "appid": self.app_id,
            "secret": self.app_secret,
            "code": code,
            "grant_type": "authorization_code"
        }
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(self.ACCESS_TOKEN_URL, params=params)
                response.raise_for_status()
                data = response.json()
                
                if "errcode" in data:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"WeChat API error: {data.get('errmsg', 'Unknown error')}"
                    )
                
                return data
                
            except httpx.HTTPError as e:
                raise HTTPException(
                    status_code=status.HTTP_502_BAD_GATEWAY,
                    detail=f"Failed to communicate with WeChat API: {str(e)}"
                )
    
    async def get_user_info(self, access_token: str, openid: str) -> Dict:
        """
        Get WeChat user information
        
        Args:
            access_token: WeChat access token
            openid: WeChat OpenID
            
        Returns:
            Dict containing user information
        """
        params = {
            "access_token": access_token,
            "openid": openid,
            "lang": "zh_CN"  # Language: zh_CN, zh_TW, en
        }
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(self.USER_INFO_URL, params=params)
                response.raise_for_status()
                data = response.json()
                
                if "errcode" in data:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail=f"WeChat API error: {data.get('errmsg', 'Unknown error')}"
                    )
                
                return data
                
            except httpx.HTTPError as e:
                raise HTTPException(
                    status_code=status.HTTP_502_BAD_GATEWAY,
                    detail=f"Failed to get WeChat user info: {str(e)}"
                )
    
    async def authenticate(self, code: str) -> Dict:
        """
        Complete WeChat OAuth authentication flow
        
        Args:
            code: Authorization code from WeChat
            
        Returns:
            Dict containing user information including openid, unionid, nickname, avatar, etc.
        """
        self.check_enabled()
        
        # Step 1: Get access token
        token_data = await self.get_access_token(code)
        
        access_token = token_data.get("access_token")
        openid = token_data.get("openid")
        unionid = token_data.get("unionid")  # Only available if app is in WeChat Open Platform
        
        # Step 2: Get user info
        user_info = await self.get_user_info(access_token, openid)
        
        # Combine token data and user info
        return {
            "openid": openid,
            "unionid": unionid,
            "nickname": user_info.get("nickname"),
            "avatar": user_info.get("headimgurl"),
            "gender": user_info.get("sex"),  # 1=male, 2=female, 0=unknown
            "city": user_info.get("city"),
            "province": user_info.get("province"),
            "country": user_info.get("country"),
            "access_token": access_token,
            "refresh_token": token_data.get("refresh_token"),
            "expires_in": token_data.get("expires_in")
        }


# Singleton instance
wechat_oauth = WeChatOAuth()
