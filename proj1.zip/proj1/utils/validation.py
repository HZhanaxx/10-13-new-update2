"""
Input Validation Utilities
Validates and sanitizes user inputs to prevent security vulnerabilities
"""
import re
import html
import bleach
from typing import Optional
from fastapi import HTTPException, status


class InputValidator:
    """
    Comprehensive input validation and sanitization
    """
    
    # Regex patterns
    PHONE_PATTERN = re.compile(r'^1[3-9]\d{9}$')
    EMAIL_PATTERN = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    UUID_PATTERN = re.compile(
        r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$',
        re.IGNORECASE
    )
    USERNAME_PATTERN = re.compile(r'^[a-zA-Z0-9_\u4e00-\u9fa5]{2,50}$')
    
    # Allowed HTML tags for rich text (if needed)
    ALLOWED_TAGS = ['b', 'i', 'u', 'strong', 'em', 'br', 'p']
    ALLOWED_ATTRIBUTES = {}
    
    @staticmethod
    def validate_phone(phone: str) -> str:
        """
        Validate Chinese phone number format
        
        Args:
            phone: Phone number string
            
        Returns:
            Cleaned phone number
            
        Raises:
            HTTPException: If phone number is invalid
        """
        if not phone:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="手机号不能为空"
            )
        
        # Remove any whitespace
        phone = phone.strip()
        
        if not InputValidator.PHONE_PATTERN.match(phone):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="手机号格式不正确"
            )
        
        return phone
    
    @staticmethod
    def validate_email(email: str) -> str:
        """
        Validate email format
        
        Args:
            email: Email address string
            
        Returns:
            Cleaned email
            
        Raises:
            HTTPException: If email is invalid
        """
        if not email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="邮箱不能为空"
            )
        
        email = email.strip().lower()
        
        if not InputValidator.EMAIL_PATTERN.match(email):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="邮箱格式不正确"
            )
        
        return email
    
    @staticmethod
    def validate_uuid(uuid_str: str, field_name: str = "UUID") -> str:
        """
        Validate UUID format
        
        Args:
            uuid_str: UUID string
            field_name: Field name for error message
            
        Returns:
            Cleaned UUID
            
        Raises:
            HTTPException: If UUID is invalid
        """
        if not uuid_str:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"{field_name}不能为空"
            )
        
        uuid_str = uuid_str.strip()
        
        if not InputValidator.UUID_PATTERN.match(uuid_str):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"{field_name}格式不正确"
            )
        
        return uuid_str
    
    @staticmethod
    def validate_username(username: str) -> str:
        """
        Validate username format
        
        Args:
            username: Username string
            
        Returns:
            Cleaned username
            
        Raises:
            HTTPException: If username is invalid
        """
        if not username:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="用户名不能为空"
            )
        
        username = username.strip()
        
        if not InputValidator.USERNAME_PATTERN.match(username):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="用户名格式不正确（2-50个字符，仅支持字母、数字、下划线和中文）"
            )
        
        return username
    
    @staticmethod
    def validate_text(
        text: str, 
        field_name: str = "文本",
        min_length: int = 1,
        max_length: int = 5000,
        allow_empty: bool = False
    ) -> str:
        """
        Validate and sanitize text input
        
        Args:
            text: Input text
            field_name: Field name for error message
            min_length: Minimum length
            max_length: Maximum length
            allow_empty: Whether empty string is allowed
            
        Returns:
            Sanitized text
            
        Raises:
            HTTPException: If text is invalid
        """
        if text is None:
            if allow_empty:
                return ""
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"{field_name}不能为空"
            )
        
        # Strip whitespace
        text = text.strip()
        
        if not text and not allow_empty:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"{field_name}不能为空"
            )
        
        # Check length
        if len(text) < min_length:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"{field_name}长度不能少于{min_length}个字符"
            )
        
        if len(text) > max_length:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"{field_name}长度不能超过{max_length}个字符"
            )
        
        # Sanitize HTML (escape all HTML)
        text = html.escape(text)
        
        return text
    
    @staticmethod
    def sanitize_html(
        html_text: str,
        field_name: str = "HTML内容"
    ) -> str:
        """
        Sanitize HTML input (for rich text fields)
        
        Args:
            html_text: HTML text
            field_name: Field name for error message
            
        Returns:
            Sanitized HTML
        """
        if not html_text:
            return ""
        
        # Use bleach to sanitize HTML
        clean_html = bleach.clean(
            html_text,
            tags=InputValidator.ALLOWED_TAGS,
            attributes=InputValidator.ALLOWED_ATTRIBUTES,
            strip=True
        )
        
        return clean_html
    
    @staticmethod
    def validate_number(
        value: any,
        field_name: str = "数值",
        min_value: Optional[float] = None,
        max_value: Optional[float] = None
    ) -> float:
        """
        Validate numeric input
        
        Args:
            value: Input value
            field_name: Field name for error message
            min_value: Minimum value
            max_value: Maximum value
            
        Returns:
            Validated number
            
        Raises:
            HTTPException: If value is invalid
        """
        try:
            num = float(value)
        except (ValueError, TypeError):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"{field_name}必须是有效的数字"
            )
        
        if min_value is not None and num < min_value:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"{field_name}不能小于{min_value}"
            )
        
        if max_value is not None and num > max_value:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"{field_name}不能大于{max_value}"
            )
        
        return num
    
    @staticmethod
    def validate_file_upload(
        filename: str,
        max_size_mb: int = 10,
        allowed_extensions: list = None
    ) -> str:
        """
        Validate file upload
        
        Args:
            filename: File name
            max_size_mb: Maximum file size in MB
            allowed_extensions: List of allowed file extensions
            
        Returns:
            Cleaned filename
            
        Raises:
            HTTPException: If file is invalid
        """
        if not filename:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="文件名不能为空"
            )
        
        # Remove path traversal attempts
        filename = filename.split('/')[-1].split('\\')[-1]
        
        # Check extension
        if allowed_extensions:
            ext = filename.rsplit('.', 1)[-1].lower()
            if ext not in allowed_extensions:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"不支持的文件类型。允许的类型: {', '.join(allowed_extensions)}"
                )
        
        return filename


# Convenience function for validating case data
def validate_case_data(data: dict) -> dict:
    """
    Validate case creation/update data
    
    Args:
        data: Case data dictionary
        
    Returns:
        Validated and sanitized data
    """
    validator = InputValidator()
    
    validated = {}
    
    # Title
    if 'title' in data:
        validated['title'] = validator.validate_text(
            data['title'],
            field_name="案件标题",
            min_length=5,
            max_length=200
        )
    
    # Description
    if 'description' in data:
        validated['description'] = validator.validate_text(
            data['description'],
            field_name="案件描述",
            min_length=20,
            max_length=5000
        )
    
    # Category
    if 'case_category' in data:
        validated['case_category'] = validator.validate_text(
            data['case_category'],
            field_name="案件类别",
            max_length=50
        )
    
    # Budget
    if 'budget_cny' in data and data['budget_cny'] is not None:
        validated['budget_cny'] = validator.validate_number(
            data['budget_cny'],
            field_name="预算",
            min_value=0,
            max_value=10000000
        )
    
    # Priority
    if 'priority' in data:
        allowed_priorities = ['low', 'medium', 'high', 'urgent']
        if data['priority'] not in allowed_priorities:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"优先级必须是以下之一: {', '.join(allowed_priorities)}"
            )
        validated['priority'] = data['priority']
    
    return validated
