import redis.asyncio as redis
from typing import Optional
from config import settings


class RedisClient:
    """Redis client for token management and rate limiting"""
    
    def __init__(self):
        self.redis: Optional[redis.Redis] = None
    
    async def connect(self):
        """Connect to Redis"""
        redis_url = f"redis://{settings.REDIS_HOST}:{settings.REDIS_PORT}/{settings.REDIS_DB}"
        if settings.REDIS_PASSWORD:
            redis_url = f"redis://:{settings.REDIS_PASSWORD}@{settings.REDIS_HOST}:{settings.REDIS_PORT}/{settings.REDIS_DB}"
        
        self.redis = await redis.from_url(
            redis_url,
            encoding="utf-8",
            decode_responses=True
        )
        print(f"✓ Connected to Redis at {settings.REDIS_HOST}:{settings.REDIS_PORT}")
    
    async def close(self):
        """Close Redis connection"""
        if self.redis:
            await self.redis.close()
            print("✓ Redis connection closed")
    
    # ===== Token Management =====
    
    async def store_access_token(self, jti: str, user_uuid: str, expires_in: int):
        """Store access token in Redis with expiration"""
        key = f"access_token:{jti}"
        await self.redis.setex(key, expires_in, user_uuid)
    
    async def get_access_token(self, jti: str) -> Optional[str]:
        """Get access token from Redis"""
        key = f"access_token:{jti}"
        return await self.redis.get(key)
    
    async def revoke_access_token(self, jti: str):
        """Revoke access token by deleting from Redis"""
        key = f"access_token:{jti}"
        await self.redis.delete(key)
    
    async def store_refresh_token(self, jti: str, user_uuid: str, expires_in: int):
        """Store refresh token in Redis with expiration"""
        key = f"refresh_token:{jti}"
        await self.redis.setex(key, expires_in, user_uuid)
    
    async def get_refresh_token(self, jti: str) -> Optional[str]:
        """Get refresh token from Redis"""
        key = f"refresh_token:{jti}"
        return await self.redis.get(key)
    
    async def revoke_refresh_token(self, jti: str):
        """Revoke refresh token by deleting from Redis"""
        key = f"refresh_token:{jti}"
        await self.redis.delete(key)
    
    # ===== Session Management =====
    
    async def add_user_session(self, user_uuid: str, session_uuid: str):
        """Add session to user's active sessions set"""
        key = f"user_sessions:{user_uuid}"
        await self.redis.sadd(key, session_uuid)
    
    async def remove_user_session(self, user_uuid: str, session_uuid: str):
        """Remove session from user's active sessions"""
        key = f"user_sessions:{user_uuid}"
        await self.redis.srem(key, session_uuid)
    
    async def get_user_sessions(self, user_uuid: str) -> list:
        """Get all active sessions for a user"""
        key = f"user_sessions:{user_uuid}"
        sessions = await self.redis.smembers(key)
        return list(sessions) if sessions else []
    
    async def revoke_all_user_sessions(self, user_uuid: str):
        """Revoke all sessions for a user"""
        key = f"user_sessions:{user_uuid}"
        sessions = await self.get_user_sessions(user_uuid)
        for session_uuid in sessions:
            await self.remove_user_session(user_uuid, session_uuid)
        await self.redis.delete(key)
    
    # ===== SMS Verification =====
    
    async def store_sms_code(self, phone: str, code: str, expires_in: int):
        """Store SMS verification code with expiration"""
        key = f"sms_code:{phone}"
        await self.redis.setex(key, expires_in, code)
    
    async def get_sms_code(self, phone: str) -> Optional[str]:
        """Get SMS verification code"""
        key = f"sms_code:{phone}"
        return await self.redis.get(key)
    
    async def delete_sms_code(self, phone: str):
        """Delete SMS code after verification"""
        key = f"sms_code:{phone}"
        await self.redis.delete(key)
    
    # ===== Rate Limiting =====
    
    async def check_rate_limit(self, key: str, max_attempts: int, window_seconds: int) -> bool:
        """
        Check if rate limit is exceeded
        Returns True if within limit, False if exceeded
        """
        current = await self.redis.incr(key)
        if current == 1:
            await self.redis.expire(key, window_seconds)
        return current <= max_attempts
    
    async def get_rate_limit_count(self, key: str) -> int:
        """Get current count for rate limit key"""
        count = await self.redis.get(key)
        return int(count) if count else 0
    
    async def reset_rate_limit(self, key: str):
        """Reset rate limit counter"""
        await self.redis.delete(key)
    
    # ===== Login Attempts Tracking =====
    
    async def increment_login_attempts(self, identifier: str) -> int:
        """Increment failed login attempts"""
        key = f"login_attempts:{identifier}"
        count = await self.redis.incr(key)
        if count == 1:
            # Set expiration on first attempt
            await self.redis.expire(key, settings.LOCKOUT_DURATION_MINUTES * 60)
        return count
    
    async def get_login_attempts(self, identifier: str) -> int:
        """Get failed login attempts count"""
        key = f"login_attempts:{identifier}"
        count = await self.redis.get(key)
        return int(count) if count else 0
    
    async def reset_login_attempts(self, identifier: str):
        """Reset failed login attempts"""
        key = f"login_attempts:{identifier}"
        await self.redis.delete(key)
    
    async def is_account_locked(self, identifier: str) -> bool:
        """Check if account is locked due to too many failed attempts"""
        attempts = await self.get_login_attempts(identifier)
        return attempts >= settings.MAX_LOGIN_ATTEMPTS


# Global Redis client instance
redis_client = RedisClient()
