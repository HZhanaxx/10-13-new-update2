from datetime import datetime, timedelta
from typing import Optional, Dict
from jose import JWTError, jwt
import bcrypt  # ✅ Changed: Using bcrypt directly instead of passlib
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
import uuid
import hashlib

from config import settings
from database import get_db
from models.user import User, UserSession, RefreshToken
from utils.redis_client import redis_client

# OAuth2 scheme
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/login")


# ✅ FIX: New Hashing Logic (Replaces passlib)
def get_password_hash(password: str) -> str:
    """
    Hash a password using bcrypt.
    Fixes the 'password too long' error by using the library directly.
    """
    # bcrypt requires bytes input
    pwd_bytes = password.encode('utf-8')
    # Generate salt and hash
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(pwd_bytes, salt)
    # Return as string for database storage
    return hashed.decode('utf-8')


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify a password against a hash using bcrypt.
    """
    try:
        pwd_bytes = plain_password.encode('utf-8')
        hash_bytes = hashed_password.encode('utf-8')
        return bcrypt.checkpw(pwd_bytes, hash_bytes)
    except Exception:
        # valid_hash checks can fail if the hash format is wrong
        return False


def create_access_token(
        data: dict,
        expires_delta: Optional[timedelta] = None
) -> tuple[str, str]:
    """
    Create JWT access token
    Returns: (token, jti)
    """
    to_encode = data.copy()
    jti = str(uuid.uuid4())

    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)

    to_encode.update({
        "exp": expire,
        "iat": datetime.utcnow(),
        "jti": jti,
        "type": "access"
    })

    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt, jti


def create_refresh_token(
        data: dict,
        expires_delta: Optional[timedelta] = None
) -> tuple[str, str]:
    """
    Create JWT refresh token
    Returns: (token, jti)
    """
    to_encode = data.copy()
    jti = str(uuid.uuid4())

    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)

    to_encode.update({
        "exp": expire,
        "iat": datetime.utcnow(),
        "jti": jti,
        "type": "refresh"
    })

    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt, jti


def decode_token(token: str) -> Dict:
    """Decode and verify JWT token"""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )


def hash_token(token: str) -> str:
    """Hash token for storage"""
    return hashlib.sha256(token.encode()).hexdigest()


async def get_current_user(
        token: str = Depends(oauth2_scheme),
        db: Session = Depends(get_db)
) -> User:
    """Get current authenticated user with Redis validation"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        payload = decode_token(token)
        user_uuid: str = payload.get("sub")
        token_type: str = payload.get("type")
        jti: str = payload.get("jti")

        if user_uuid is None or token_type != "access":
            raise credentials_exception

    except JWTError:
        raise credentials_exception

    # SECURITY: Check Redis first (fast validation)
    redis_user_uuid = await redis_client.get_access_token(jti)
    if redis_user_uuid is None or redis_user_uuid != user_uuid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has been revoked or is invalid"
        )

    # Check if session is active in database
    session = db.query(UserSession).filter(
        UserSession.access_token_jti == jti,
        UserSession.is_active == True,
        UserSession.expires_at > datetime.utcnow()
    ).first()

    if not session:
        # Session expired in DB, remove from Redis
        await redis_client.revoke_access_token(jti)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Session expired or invalid"
        )

    # Get user
    user = db.query(User).filter(User.user_uuid == user_uuid).first()
    if user is None:
        raise credentials_exception

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive"
        )

    # Update last activity
    session.last_activity_at = datetime.utcnow()
    db.commit()

    return user


async def get_current_active_user(
        current_user: User = Depends(get_current_user)
) -> User:
    """Get current active user"""
    if not current_user.is_active:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user


def user_to_dict(user: User) -> dict:
    """Convert User object to dict for API responses"""
    return {
        "user_uuid": str(user.user_uuid),
        "username": user.username,
        "phone": user.phone,
        "wechat_openid": user.wechat_openid,
        "role": user.role,
        "is_active": user.is_active,
        "is_verified": user.is_verified,
        "last_login_at": user.last_login_at.isoformat() if user.last_login_at else None,
        "created_at": user.created_at.isoformat() if user.created_at else None
    }


async def get_current_user_dict(
        current_user: User = Depends(get_current_user)
) -> dict:
    """Get current user as dictionary"""
    return user_to_dict(current_user)


async def get_current_verified_user(
        current_user: User = Depends(get_current_user)
) -> User:
    """Get current verified user"""
    if not current_user.is_verified:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User not verified"
        )
    return current_user


def check_user_role(required_roles: list):
    """Dependency to check user role"""

    async def role_checker(current_user: User = Depends(get_current_user)):
        if current_user.role not in required_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )
        return current_user

    return role_checker


def require_role(role: str):
    """
    Simpler dependency to require a specific role
    Usage: current_user: dict = Depends(require_role("admin"))
    """

    async def role_checker(current_user: User = Depends(get_current_user)) -> dict:
        if current_user.role != role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"This endpoint requires {role} role"
            )
        # Return user data as dict for easier use in endpoints
        return {
            "user_uuid": str(current_user.user_uuid),
            "username": current_user.username,
            "role": current_user.role,
            "is_active": current_user.is_active,
            "is_verified": current_user.is_verified
        }

    return role_checker


async def create_user_session_with_redis(
        db: Session,
        user_uuid: uuid.UUID,
        access_jti: str,
        refresh_jti: str,
        ip_address: str,
        user_agent: str,
        device_info: dict,
        expires_at: datetime
) -> UserSession:
    """Create a new user session and store tokens in Redis"""
    # Create session in database
    session = UserSession(
        user_uuid=user_uuid,
        access_token_jti=access_jti,
        refresh_token_jti=refresh_jti,
        ip_address=ip_address,
        user_agent=user_agent,
        device_info=device_info,
        expires_at=expires_at
    )
    db.add(session)
    db.commit()
    db.refresh(session)

    # Store access token in Redis
    access_expires_in = int((expires_at - datetime.utcnow()).total_seconds())
    await redis_client.store_access_token(
        access_jti,
        str(user_uuid),
        access_expires_in
    )

    # Store refresh token in Redis
    refresh_expires_in = settings.REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60
    await redis_client.store_refresh_token(
        refresh_jti,
        str(user_uuid),
        refresh_expires_in
    )

    # Add session to user's active sessions in Redis
    await redis_client.add_user_session(str(user_uuid), str(session.session_uuid))

    return session


def create_user_session(
        db: Session,
        user_uuid: uuid.UUID,
        access_jti: str,
        refresh_jti: str,
        ip_address: str,
        user_agent: str,
        device_info: dict,
        expires_at: datetime
) -> UserSession:
    """Create a new user session (sync version for backward compatibility)"""
    import asyncio
    return asyncio.run(create_user_session_with_redis(
        db, user_uuid, access_jti, refresh_jti,
        ip_address, user_agent, device_info, expires_at
    ))


async def revoke_user_session_with_redis(db: Session, session_uuid: uuid.UUID):
    """Revoke a user session and remove from Redis"""
    session = db.query(UserSession).filter(
        UserSession.session_uuid == session_uuid
    ).first()

    if session:
        # Revoke tokens in Redis
        await redis_client.revoke_access_token(session.access_token_jti)
        if session.refresh_token_jti:
            await redis_client.revoke_refresh_token(session.refresh_token_jti)

        # Remove from user's active sessions in Redis
        await redis_client.remove_user_session(
            str(session.user_uuid),
            str(session_uuid)
        )

        # Mark session as inactive in database
        session.is_active = False

        # Revoke associated refresh tokens
        db.query(RefreshToken).filter(
            RefreshToken.session_uuid == session_uuid,
            RefreshToken.is_revoked == False
        ).update({
            "is_revoked": True,
            "revoked_at": datetime.utcnow(),
            "revoked_reason": "session_revoked"
        })

        db.commit()


def revoke_user_session(db: Session, session_uuid: uuid.UUID):
    """Revoke a user session (sync version for backward compatibility)"""
    import asyncio
    asyncio.run(revoke_user_session_with_redis(db, session_uuid))