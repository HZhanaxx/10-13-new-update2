from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from config import settings
from database import engine, Base
from routers import auth, profile, admin, professional_api, cases, questionnaire, n8n_integration, verification
from utils.redis_client import redis_client


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan events"""
    # Startup
    print("🚀 Starting Legal Assistant API...")
    print(f"📡 API Server: http://localhost:8000")
    print(f"🎨 Frontend: http://localhost:3000")
    print(f"📚 API Docs: http://localhost:8000/docs")
    
    # Create database tables
    Base.metadata.create_all(bind=engine)
    
    # Initialize Redis connection
    await redis_client.connect()
    print("✅ Redis connected")
    
    yield
    
    # Shutdown
    print("Shutting down...")
    
    # Close Redis connection
    await redis_client.close()


# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware - Allow Vue3 frontend on port 3000
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,  # Should include http://localhost:3000
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routers
app.include_router(auth.router)
app.include_router(profile.router)
app.include_router(professional_api.router)
app.include_router(cases.router)
app.include_router(admin.router)
app.include_router(questionnaire.router)  # ✨ Added questionnaire router
app.include_router(n8n_integration.router)  # ✨ Added n8n integration router
app.include_router(verification.router)  # ✨ Added verification router


@app.get("/")
async def root():
    """
    API root endpoint
    This is a pure API backend - frontend runs separately on port 3000
    """
    return {
        "message": "Legal Assistant API",
        "version": settings.APP_VERSION,
        "status": "running",
        "docs": "/docs",
        "frontend_url": "http://localhost:3000",
        "api_endpoints": {
            "auth": "/api/auth",
            "profile": "/api/profile",
            "cases": "/api/cases",
            "admin": "/api/admin",
            "professional": "/api/professional",
            "questionnaire": "/api/questionnaire",
            "n8n": "/api/n8n",  # ✨ Added n8n endpoint
            "verification": "/api/verification"  # ✨ Added verification endpoint
        }
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        redis_status = await redis_client.ping()
        return {
            "status": "healthy",
            "redis": "connected" if redis_status else "disconnected",
            "database": "connected"
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "error": str(e)
        }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG
    )
