from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # Application
    APP_NAME: str = "Auth System"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True
    
    # Database
    DATABASE_URL: str = "postgresql://legal_assistant_user:zxzxzx020718@localhost:5432/legal_assistant"
    
    # JWT Settings
    SECRET_KEY: str = "dGhpcyBpcyBhIHZlcnkgc2VjdXJlIGtleSB0aGF0IHlvdSBzaG91bGQgY2hhbmdlIGltbWVkaWF0ZWx5IGZvciBwcm9kdWN0aW9u"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # n8n Integration
    N8N_WEBHOOK_BASE_URL: str = "http://localhost:5678/webhook-test"
    N8N_JWT_SECRET: str = "8f7d9e2a1b4c6f8e0d3a5b7c9e1f4a6b8d0e2f4a6c8e0b2d4f6a8c0e2b4d6f8a0c2e4f6b8d0a2c4e6f8b0d2e4f6a8c0"
    N8N_JWT_ALGORITHM: str = "HS256"
    N8N_JWT_EXPIRE_HOURS: float = 0.5
    
    # Ollama Settings
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    OLLAMA_MODEL: str = "qwen3:8b"
    
    # Redis (for session management)
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_PASSWORD: Optional[str] = None
    
    # WeChat OAuth (Optional - leave empty if not using)
    WECHAT_APP_ID: Optional[str] = None
    WECHAT_APP_SECRET: Optional[str] = None
    WECHAT_REDIRECT_URI: Optional[str] = None
    WECHAT_ENABLED: bool = False  # Set to True when WeChat is configured
    
    # SMS Settings (example with Aliyun)
    SMS_ACCESS_KEY_ID: str = ""
    SMS_ACCESS_KEY_SECRET: str = ""
    SMS_SIGN_NAME: str = "Your App"
    SMS_TEMPLATE_CODE: str = "SMS_123456789"
    
    # CORS
    CORS_ORIGINS: list = [
        "http://localhost:8080",
        "http://localhost:3000",
        "http://127.0.0.1:8080"
    ]
    
    # Security
    PASSWORD_MIN_LENGTH: int = 8
    BCRYPT_ROUNDS: int = 12
    SMS_CODE_EXPIRE_MINUTES: int = 5
    MAX_LOGIN_ATTEMPTS: int = 5
    LOCKOUT_DURATION_MINUTES: int = 30
    
    class Config:
        env_file = ".env"
        case_sensitive = True
    
    def is_wechat_enabled(self) -> bool:
        """Check if WeChat OAuth is properly configured"""
        return (
            self.WECHAT_ENABLED and
            self.WECHAT_APP_ID is not None and
            self.WECHAT_APP_SECRET is not None and
            self.WECHAT_REDIRECT_URI is not None and
            self.WECHAT_APP_ID != "" and
            self.WECHAT_APP_SECRET != ""
        )


settings = Settings()
