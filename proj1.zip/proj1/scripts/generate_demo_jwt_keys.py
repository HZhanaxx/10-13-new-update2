#!/usr/bin/env python3
"""
Demo JWT Key Generator for N8N Integration Testing
生成用于测试 n8n 工作流的 JWT 密钥和 Token

WARNING: These are for DEVELOPMENT/TESTING only!
         Do NOT use in production!
"""

import secrets
import jwt
from datetime import datetime, timedelta
import uuid
import json
import sys


def generate_demo_keys():
    """Generate demo JWT secret key"""
    secret_key = secrets.token_urlsafe(32)
    return secret_key


def create_demo_token(secret_key: str, user_uuid: str = None, session_id: str = None, hours: int = 24):
    """Create a demo JWT token for testing"""
    if not user_uuid:
        user_uuid = str(uuid.uuid4())
    
    if not session_id:
        session_id = f"demo_sess_{uuid.uuid4().hex[:8]}"
    
    payload = {
        "sub": user_uuid,
        "session_id": session_id,
        "type": "n8n_webhook",
        "iat": datetime.utcnow(),
        "exp": datetime.utcnow() + timedelta(hours=hours),
        "jti": str(uuid.uuid4())
    }
    
    token = jwt.encode(payload, secret_key, algorithm="HS256")
    return token, payload


def verify_token(token: str, secret_key: str):
    """Verify a JWT token"""
    try:
        decoded = jwt.verify(token, secret_key, algorithms=["HS256"])
        return True, decoded
    except jwt.ExpiredSignatureError:
        return False, "Token has expired"
    except jwt.InvalidTokenError as e:
        return False, str(e)


def main():
    print("=" * 60)
    print("N8N Integration - Demo JWT Key Generator")
    print("=" * 60)
    print()
    print("⚠️  WARNING: These keys are for DEVELOPMENT/TESTING only!")
    print("    Do NOT use in production environments!")
    print()
    print("-" * 60)
    
    # Generate new secret key
    secret_key = generate_demo_keys()
    print(f"\n🔑 Generated JWT Secret Key:")
    print(f"   {secret_key}")
    
    # Create demo token
    token, payload = create_demo_token(secret_key)
    
    print(f"\n📝 Demo Token Payload:")
    print(f"   User UUID: {payload['sub']}")
    print(f"   Session ID: {payload['session_id']}")
    print(f"   Type: {payload['type']}")
    print(f"   Expires: {payload['exp'].isoformat()}")
    
    print(f"\n🎫 Demo JWT Token:")
    print(f"   {token}")
    
    # Generate .env content
    print(f"\n📄 Add to your .env file:")
    print("-" * 60)
    print(f"# N8N JWT Configuration (Demo Keys)")
    print(f"N8N_JWT_SECRET={secret_key}")
    print(f"N8N_WEBHOOK_BASE_URL=http://localhost:5678/webhook")
    print("-" * 60)
    
    # Generate n8n environment variable
    print(f"\n📄 N8N Environment Variables:")
    print("-" * 60)
    print(f"JWT_SECRET={secret_key}")
    print("-" * 60)
    
    # Generate test curl command
    print(f"\n🧪 Test curl command:")
    print("-" * 60)
    curl_cmd = f'''curl -X POST http://localhost:5678/webhook/questionnaire-start \\
  -H "Content-Type: application/json" \\
  -d '{{"jwt": "{token}", "action": "start", "templateType": 1}}'
'''
    print(curl_cmd)
    print("-" * 60)
    
    # Generate Python test code
    print(f"\n🐍 Python test code:")
    print("-" * 60)
    python_code = f'''import requests

url = "http://localhost:5678/webhook/questionnaire-start"
headers = {{"Content-Type": "application/json"}}
data = {{
    "jwt": "{token}",
    "action": "start",
    "templateType": 1
}}

response = requests.post(url, json=data, headers=headers)
print(response.json())
'''
    print(python_code)
    print("-" * 60)
    
    # Save to file option
    if len(sys.argv) > 1 and sys.argv[1] == "--save":
        output = {
            "secret_key": secret_key,
            "demo_token": token,
            "payload": {
                "sub": payload["sub"],
                "session_id": payload["session_id"],
                "type": payload["type"],
                "exp": payload["exp"].isoformat()
            },
            "generated_at": datetime.utcnow().isoformat()
        }
        
        filename = "demo_jwt_keys.json"
        with open(filename, "w") as f:
            json.dump(output, f, indent=2)
        print(f"\n✅ Keys saved to {filename}")
    else:
        print("\n💡 Tip: Run with --save to save keys to file")
    
    print()
    print("=" * 60)
    print("Setup Complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
