#!/usr/bin/env python3
"""
问卷系统数据库迁移脚本
运行此脚本以创建问卷系统所需的数据库表
"""

import sys
import os

# 添加项目根目录到 Python 路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database import Base, engine
from models.user import User  # 确保基础模型已加载
from models.questionnaire import QuestionnaireSession, QuestionnaireSubmission


def create_questionnaire_tables():
    """创建问卷系统表"""
    print("🔄 开始创建问卷系统数据库表...")
    
    try:
        # 创建所有表（如果不存在）
        Base.metadata.create_all(bind=engine)
        print("✅ 数据库表创建成功！")
        
        # 列出创建的表
        print("\n📊 已创建的表:")
        print("  - questionnaire_sessions (问卷会话表)")
        print("  - questionnaire_submissions (问卷提交表)")
        
        print("\n✨ 迁移完成！")
        
    except Exception as e:
        print(f"❌ 创建表失败: {e}")
        sys.exit(1)


def verify_tables():
    """验证表是否成功创建"""
    from sqlalchemy import inspect
    
    print("\n🔍 验证表结构...")
    
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    
    required_tables = ['questionnaire_sessions', 'questionnaire_submissions']
    
    for table in required_tables:
        if table in tables:
            print(f"  ✅ {table}")
        else:
            print(f"  ❌ {table} (未找到)")
    
    print("\n验证完成！")


if __name__ == "__main__":
    print("=" * 60)
    print("问卷系统数据库迁移")
    print("=" * 60)
    
    # 创建表
    create_questionnaire_tables()
    
    # 验证表
    verify_tables()
    
    print("\n" + "=" * 60)
    print("下一步：")
    print("  1. 启动后端服务: python main.py")
    print("  2. 访问 API 文档: http://localhost:8000/docs")
    print("  3. 测试问卷 API 端点")
    print("=" * 60)
