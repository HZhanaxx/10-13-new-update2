"""
Security Middleware for FastAPI Application
Implements rate limiting, security headers, and request validation
"""
from fastapi import Request, HTTPException, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from datetime import datetime, timedelta
from collections import defaultdict
from typing import Dict, Optional
import time
import re
import logging

logger = logging.getLogger(__name__)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Rate limiting middleware to prevent abuse and DDoS attacks
    """
    def __init__(self, app, requests_per_minute: int = 60, requests_per_hour: int = 1000):
        super().__init__(app)
        self.requests_per_minute = requests_per_minute
        self.requests_per_hour = requests_per_hour
        
        # Store request timestamps per IP
        self.request_history: Dict[str, list] = defaultdict(list)
        
        # Cleanup interval (seconds)
        self.cleanup_interval = 300  # 5 minutes
        self.last_cleanup = time.time()
    
    async def dispatch(self, request: Request, call_next):
        # Skip rate limiting for health check
        if request.url.path == "/health":
            return await call_next(request)
        
        # Get client IP (considering proxy headers)
        client_ip = self._get_client_ip(request)
        
        # Check rate limits
        if not self._check_rate_limit(client_ip):
            logger.warning(f"Rate limit exceeded for IP: {client_ip}")
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={"detail": "请求过于频繁，请稍后再试"}
            )
        
        # Record request
        self._record_request(client_ip)
        
        # Periodic cleanup of old entries
        if time.time() - self.last_cleanup > self.cleanup_interval:
            self._cleanup_old_entries()
        
        # Continue processing
        response = await call_next(request)
        return response
    
    def _get_client_ip(self, request: Request) -> str:
        """Get client IP address, considering proxy headers"""
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return forwarded.split(",")[0].strip()
        
        real_ip = request.headers.get("X-Real-IP")
        if real_ip:
            return real_ip
        
        return request.client.host if request.client else "unknown"
    
    def _check_rate_limit(self, client_ip: str) -> bool:
        """Check if request is within rate limits"""
        now = datetime.now()
        requests = self.request_history[client_ip]
        
        # Filter requests within time windows
        minute_ago = now - timedelta(minutes=1)
        hour_ago = now - timedelta(hours=1)
        
        recent_requests_minute = [r for r in requests if r > minute_ago]
        recent_requests_hour = [r for r in requests if r > hour_ago]
        
        # Check limits
        if len(recent_requests_minute) >= self.requests_per_minute:
            return False
        
        if len(recent_requests_hour) >= self.requests_per_hour:
            return False
        
        return True
    
    def _record_request(self, client_ip: str):
        """Record request timestamp"""
        self.request_history[client_ip].append(datetime.now())
    
    def _cleanup_old_entries(self):
        """Remove old request history to save memory"""
        cutoff = datetime.now() - timedelta(hours=2)
        
        for ip in list(self.request_history.keys()):
            self.request_history[ip] = [
                r for r in self.request_history[ip] if r > cutoff
            ]
            
            # Remove empty entries
            if not self.request_history[ip]:
                del self.request_history[ip]
        
        self.last_cleanup = time.time()
        logger.info(f"Cleaned up rate limit history. Active IPs: {len(self.request_history)}")


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    Add security headers to all responses
    """
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        
        # Security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: https:; "
            "font-src 'self'; "
            "connect-src 'self'; "
            "frame-ancestors 'none'"
        )
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        
        return response


class InputValidationMiddleware(BaseHTTPMiddleware):
    """
    Validate and sanitize incoming requests to prevent attacks
    """
    # Patterns for detecting common attacks
    SQL_INJECTION_PATTERNS = [
        r"(\bunion\b.*\bselect\b)|(\bselect\b.*\bfrom\b)",
        r"(\binsert\b.*\binto\b)|(\bdelete\b.*\bfrom\b)",
        r"(\bdrop\b.*\btable\b)|(\bupdate\b.*\bset\b)",
        r"(--|#|/\*|\*/|xp_|sp_)",
        r"(\bor\b\s+\d+\s*=\s*\d+)|(\band\b\s+\d+\s*=\s*\d+)",
    ]
    
    XSS_PATTERNS = [
        r"<script[^>]*>.*?</script>",
        r"javascript:",
        r"onerror\s*=",
        r"onload\s*=",
        r"<iframe",
    ]
    
    PATH_TRAVERSAL_PATTERNS = [
        r"\.\./",
        r"\.\.",
        r"%2e%2e",
    ]
    
    def __init__(self, app):
        super().__init__(app)
        # Compile regex patterns for performance
        self.sql_patterns = [re.compile(p, re.IGNORECASE) for p in self.SQL_INJECTION_PATTERNS]
        self.xss_patterns = [re.compile(p, re.IGNORECASE) for p in self.XSS_PATTERNS]
        self.path_patterns = [re.compile(p, re.IGNORECASE) for p in self.PATH_TRAVERSAL_PATTERNS]
    
    async def dispatch(self, request: Request, call_next):
        # Check URL path
        if self._check_malicious_patterns(request.url.path):
            logger.warning(f"Malicious URL detected: {request.url.path} from {request.client.host}")
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="检测到非法请求"
            )
        
        # Check query parameters
        for key, value in request.query_params.items():
            if self._check_malicious_patterns(value):
                logger.warning(f"Malicious query param detected: {key}={value}")
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="检测到非法请求参数"
                )
        
        # Continue processing
        response = await call_next(request)
        return response
    
    def _check_malicious_patterns(self, text: str) -> bool:
        """Check text against malicious patterns"""
        if not text:
            return False
        
        # Check SQL injection
        for pattern in self.sql_patterns:
            if pattern.search(text):
                logger.warning(f"SQL injection pattern detected: {text}")
                return True
        
        # Check XSS
        for pattern in self.xss_patterns:
            if pattern.search(text):
                logger.warning(f"XSS pattern detected: {text}")
                return True
        
        # Check path traversal
        for pattern in self.path_patterns:
            if pattern.search(text):
                logger.warning(f"Path traversal pattern detected: {text}")
                return True
        
        return False
